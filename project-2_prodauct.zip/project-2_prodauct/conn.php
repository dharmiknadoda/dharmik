<?php
    $host = 'localhost';
    $user = 'root';
    $password = '';
    $database = 'project-2';

    $conn = mysqli_connect($host,$user,$password,$database);

?>