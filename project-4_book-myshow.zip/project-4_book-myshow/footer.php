<section id="footer" style="color: white;">
		<div class="footer_m clearfix">
			<div class="container">
				<div class="row footer_1">
					<div class="col-md-4">
						<div class="footer_1i" style="color: white;">
							<h3><a class="text-white" href="index.php"><i class="fa fa-video-camera col_red me-1" style="color: white;"></i> Planet</a></h3>
							<h6 class="fw-normal" style="margin-top: 50px;"><i class="fa fa-map-marker fs-5 align-middle col_red me-1" style="color: white;"></i> 5311 Ceaver Sidge Td.
								Pakland, DE 13507</h6>
							<h6 class="fw-normal mt-3"><i class="fa fa-envelope fs-5 align-middle col_red me-1" style="color: white;"></i> info@gmail.com</h6>
							<h6 class="fw-normal mt-3 mb-0"><i class="fa fa-phone fs-5 align-middle col_red me-1" style="color: white;"></i> +123 123 456</h6>
						</div>
					</div>
					<div class="col-md-4">
						<div class="footer_1i">
							<h4>Flickr <span class="col_red">Stream</span></h4>
							<div class="footer_1i1 row mt-4">
								<div class="col-md-3 col-3">
									<div class="footer_1i1i">
										<div class="grid clearfix">
											<figure class="effect-jazz mb-0">
												<a href="#"><img src="img/e-1.avif" height="70" class="w-100" alt="abc"></a>
											</figure>
										</div>
									</div>
								</div>
								<div class="col-md-3 col-3">
									<div class="footer_1i1i">
										<div class="grid clearfix">
											<figure class="effect-jazz mb-0">
												<a href="#"><img src="img/e-2.avif" height="70" class="w-100" alt="abc"></a>
											</figure>
										</div>
									</div>
								</div>
								<div class="col-md-3 col-3">
									<div class="footer_1i1i">
										<div class="grid clearfix">
											<figure class="effect-jazz mb-0">
												<a href="#"><img src="img/e-3.avif" height="70" class="w-100" alt="abc"></a>
											</figure>
										</div>
									</div>
								</div>
								<div class="col-md-3 col-3">
									<div class="footer_1i1i">
										<div class="grid clearfix">
											<figure class="effect-jazz mb-0">
												<a href="#"><img src="img/e-4.avif" height="70" class="w-100" alt="abc"></a>
											</figure>
										</div>
									</div>
								</div>
							</div>
							<div class="footer_1i1 row mt-3">
								<div class="col-md-3 col-3">
									<div class="footer_1i1i">
										<div class="grid clearfix">
											<figure class="effect-jazz mb-0">
												<a href="#"><img src="img/e-5.avif" height="70" class="w-100" alt="abc"></a>
											</figure>
										</div>
									</div>
								</div>
								<div class="col-md-3 col-3">
									<div class="footer_1i1i">
										<div class="grid clearfix">
											<figure class="effect-jazz mb-0">
												<a href="#"><img src="img/e-1.avif" height="70" class="w-100" alt="abc"></a>
											</figure>
										</div>
									</div>
								</div>
								<div class="col-md-3 col-3">
									<div class="footer_1i1i">
										<div class="grid clearfix">
											<figure class="effect-jazz mb-0">
												<a href="#"><img src="img/e-2.avif" height="70" class="w-100" alt="abc"></a>
											</figure>
										</div>
									</div>
								</div>
								<div class="col-md-3 col-3">
									<div class="footer_1i1i">
										<div class="grid clearfix">
											<figure class="effect-jazz mb-0">
												<a href="#"><img src="img/e-3.avif" height="70" class="w-100" alt="abc"></a>
											</figure>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4">
						<div class="footer_1i">
							<h4>Sign <span class="col_red"  style="color: silver;">Newsletter</span></h4>
							<p class="mt-3"  style="color: white; font-size: 15px;" >Subscribe to our newsletter list to get latest news and updates from us</p>
							<div class="input-group">
								<input type="text" class="form-control bg-black" placeholder="Email">
								<span class="input-group-btn">
									<button class="btn btn text-white bg_red rounded-0 border-0" type="button">
										Subscribe</button>
								</span>
							</div>
							<ul class="social-network social-circle mb-0 mt-4">
								<li><a href="#" class="icoRss" title="Rss"><i class="fa fa-instagram"></i></a></li>
								<li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-youtube"></i></a></li>
								<li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>