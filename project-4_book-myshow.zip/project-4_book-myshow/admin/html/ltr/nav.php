<style>
    
    a:hover{
        list-style: none;
        text-decoration: none;
    }
</style>
<aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav" class="pt-4">
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="index.php" aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span
                                    class="hide-menu">Dashboard</span></a>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="movie.php" aria-expanded="false"><i class="mdi mdi-border-inside"></i><span
                                    class="hide-menu">Add Movie</span></a>
                        </li>
                        <li class="sidebar-item"><a href="Premieres.php" class="sidebar-link"><i
                            class="mdi mdi-note-outline"></i><span class="hide-menu">Add Premieres Movie
                            </span></a>
                        </li>
                        <li class="sidebar-item"><a href="event.php" class="sidebar-link"><i
                            class="mdi mdi-note-outline"></i><span class="hide-menu">Add Event
                            </span></a>
                        </li>
                        <li class="sidebar-item"><a href="plays.php" class="sidebar-link"><i
                            class="mdi mdi-note-outline"></i><span class="hide-menu">Add Plays
                            </span></a>
                            <!-- <li xlass dharmik vipul bhai a buy_medicine.php_check_syntax> -->
                        </li>
                        <li class="sidebar-item"><a href="sport.php" class="sidebar-link"><i
                            class="mdi mdi-note-outline"></i><span class="hide-menu">Add Sport
                            </span></a>
                        </li>
                        <li class="sidebar-item"><a href="feedbacks.php" class="sidebar-link"><i
                            class="mdi mdi-note-plus"></i><span class="hide-menu"> Feedback
                            </span></a>
                        </li>

                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>