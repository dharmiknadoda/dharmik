<?php
    $host = 'localhost';
    $user = 'root';
    $password = '';
    $database = 'project-3';

    $conn = mysqli_connect($host,$user,$password,$database);

?>