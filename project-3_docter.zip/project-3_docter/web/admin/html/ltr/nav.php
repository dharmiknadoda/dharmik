<aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav" class="pt-4">
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="index.php" aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span
                                    class="hide-menu">Dashboard</span></a>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="docter.php" aria-expanded="false"><i class="mdi mdi-border-inside"></i><span
                                    class="hide-menu">Docter</span></a>
                        </li>
                        <li class="sidebar-item"><a href="medicine.php" class="sidebar-link"><i
                            class="mdi mdi-note-outline"></i><span class="hide-menu">Add Medicine
                            </span></a>
                        </li>
                        <li class="sidebar-item"><a href="buy_medicine.php" class="sidebar-link"><i
                            class="mdi mdi-note-outline"></i><span class="hide-menu">Buy Medicine
                            </span></a>
                            <li xlass dharmik vipul bhai a buy_medicine.php_check_syntax>
                        </li>
                        <li class="sidebar-item"><a href="contect.php" class="sidebar-link"><i
                            class="mdi mdi-note-outline"></i><span class="hide-menu">Contect Us
                            </span></a>
                        </li>
                        <li class="sidebar-item"><a href="appointment.php" class="sidebar-link"><i
                            class="mdi mdi-note-outline"></i><span class="hide-menu">Appointment
                            </span></a>
                        </li>
                        <li class="sidebar-item"><a href="feedbacks.php" class="sidebar-link"><i
                            class="mdi mdi-note-plus"></i><span class="hide-menu"> Feedback
                            </span></a>
                        </li>

                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>